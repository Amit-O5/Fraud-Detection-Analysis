import streamlit as st
import pandas as pd
import sqlite3

# Database Connection
conn = sqlite3.connect("transactions.db")

cursor = conn.cursor()

# Create Table
cursor.execute("""
CREATE TABLE IF NOT EXISTS transactions (
    amount REAL,
    result TEXT
)
""")

conn.commit()

# App Title
st.title("Real-Time Fraud Detection System")

# Input
amount = st.number_input("Enter Transaction Amount")

# Button
if st.button("Check Transaction"):

    # Fraud Logic
    if amount > 2000:
        result = "Fraud Transaction"
    else:
        result = "Normal Transaction"

    # Save to Database
    cursor.execute(
        "INSERT INTO transactions VALUES (?, ?)",
        (amount, result)
    )

    conn.commit()

    # Result
    if result == "Fraud Transaction":
        st.error(result)
    else:
        st.success(result)

# Show History
st.subheader("Transaction History")

cursor.execute("SELECT * FROM transactions")

data = cursor.fetchall()

history_df = pd.DataFrame(
    data,
    columns=["Amount", "Result"]
)

st.table(history_df)
uploaded_file = st.file_uploader(
    "Upload CSV File",
    type=["csv"]
)

if uploaded_file is not None:

    df = pd.read_csv(uploaded_file)

    st.write(df.head())