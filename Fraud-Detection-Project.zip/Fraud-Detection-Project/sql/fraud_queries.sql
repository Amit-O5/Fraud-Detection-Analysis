SELECT COUNT(*) FROM transactions;

SELECT COUNT(*)
FROM transactions
WHERE Class = 1;

SELECT *
FROM transactions
WHERE Amount > 1000;