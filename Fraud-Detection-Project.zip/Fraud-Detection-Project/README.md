# Fraud Detection Analysis

## Overview
This project detects fraudulent credit card transactions using Machine Learning.

## Tools Used
- Python
- Pandas
- Scikit-learn
- SQL
- Matplotlib
- Seaborn

## Features
- Data Cleaning
- Fraud Detection
- Visualization
- Anomaly Detection

## Model
Isolation Forest

## Dataset
Credit Card Fraud Dataset from Kaggle